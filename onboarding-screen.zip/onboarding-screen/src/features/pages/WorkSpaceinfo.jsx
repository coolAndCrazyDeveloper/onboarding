import React from 'react'

export default function WorkSpaceinfo({ onSubmit }) {
    return (
        <div>
            <div className='page-title'>
                <p>Let's setup a home for all your work</p>
                <p>You  can always create another Workspace later.</p>
            </div>
            <div className='form-wrapper'>
                <div className='form-block'>
                    <form autoComplete='off'>
                        <div className='form-control'>
                            <label for="workspaceName">Workspace Name</label>
                            <input type="text" id="workspaceName" name="workspaceName" placeholder="Eden" />
                        </div>
                        <div className='form-control'>
                            <label for="workspaceUrl">Workspace URL (optional)</label>
                            <input type="text" id="workspaceUrl" name="workspaceUrl" placeholder="WWW.eden.com/ " />
                        </div>
                        <button type='button' onClick={() => onSubmit("3")}>Create Workspace</button>
                    </form>
                </div>
            </div>
        </div>
    )
}
