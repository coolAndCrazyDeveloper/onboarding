import React from 'react'

export default function UserInformation({ onSubmit }) {
    return (
        <div>
            <div className='page-title'>
                <p>Welcome! First things first...</p>
                <p>You  can always change them later.</p>
            </div>
            <div className='form-wrapper'>
                <div className='form-block'>
                    <form autoComplete='off'>
                        <div className='form-control'>
                            <label for="fullName">Full Name</label>
                            <input type="text" id="fullName" name="fullName" placeholder="Steve Jobs" />
                        </div>
                        <div className='form-control'>
                            <label for="displayName">Display Name</label>
                            <input type="text" id="displayName" name="displayName" placeholder="Steve " />
                        </div>
                        <button type='button' onClick={() => onSubmit("2")}>Create Workspace</button>
                    </form>
                </div>
            </div>
        </div>
    )
}
