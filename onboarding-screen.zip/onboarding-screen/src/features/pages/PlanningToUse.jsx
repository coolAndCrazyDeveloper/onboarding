import React,{useState} from 'react'
import Block from '../../common/Block';
import mySelf from '../../assets/myself.png'
import team from '../../assets/team.png'

export default function PlanningToUse({ onSubmit }) {

    let blockType = [
        { imgSrc: mySelf, title: 'For myself', desc: 'Write better. Think more clearly. Stay organized' },
        { imgSrc: team, title: 'With my team', desc: 'Wikis, docs, tasks & projects, all in one place.' }
    ]

    const [currentType, setCurrentType] = useState("For myself");

    return (
        <div>
            <div className='page-title'>
                <p>How you are planning to use Eden?</p>
                <p>We'll streamline your setup experience accordingly </p>
            </div>
            <div className='form-wrapper'>
                <div className='form-block'>
                    <div className="block-container">
                        <Block {...blockType[0]} currentType={currentType} setCurrentType={setCurrentType}/>
                        <Block {...blockType[1]} currentType={currentType} setCurrentType={setCurrentType}/>
                    </div>
                    <button type='button' onClick={() => onSubmit("4")}>Create Workspace</button>
                </div>
            </div>
        </div>
    )
}
