import React from 'react'

export default function SuccessOnboarding({ onSubmit }) {
  return (
    <div>
      <div className='page-title'>
        <p>Congratulations, Eden!</p>
        <p>You have completed onboarding, you can start using this Eden!</p>
      </div>
      <div className='form-wrapper'>
        <div className='form-block'>
          <button type='button' onClick={() => onSubmit("1")}>Launch Eden</button>
        </div>
      </div>
    </div>
  )
}
