import React, { useState } from 'react';
import logo from '../../assets/logo.png'
import Steps from '../../common/Steps';
import '../../style/mainStyle.css'
import PlanningToUse from '../pages/PlanningToUse';
import SuccessOnboarding from '../pages/SuccessOnboarding';
import UserInformation from '../pages/UserInformation';
import WorkSpaceinfo from '../pages/WorkSpaceinfo';

export default function Layout() {
    const [currentStep, setCurrentStep] = useState("1");

    return (
        <div>
            <div className='logo'><img src={logo} /></div>
            <Steps currentStep={currentStep} />
            <div className="content">
                {currentStep === "1" && <UserInformation onSubmit={setCurrentStep} />}
                {currentStep === "2" && <WorkSpaceinfo onSubmit={setCurrentStep}/>}
                {currentStep === "3" && <PlanningToUse onSubmit={setCurrentStep}/>}
                {currentStep === "4" && <SuccessOnboarding onSubmit={setCurrentStep}/>}
            </div>
        </div>
    )
}
