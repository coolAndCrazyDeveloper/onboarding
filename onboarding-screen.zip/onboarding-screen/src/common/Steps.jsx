import React from 'react'

export default function Steps({ currentStep }) {

    const getStepClassName = (stepIndex) => {
        if (currentStep >= stepIndex)
            return "step-circle active-step"
        return "step-circle";
    }

    const getClassName = (lineIndex) => {
        if (currentStep >= lineIndex)
            return "step-line active-step"
        return "step-line";
    }

    return (
        <div className="step-wrapper">
            <div className="connected-steps">
                <div className={getStepClassName('1')}>1</div>
                <div className={getClassName('1')}></div>
                <div className={getClassName('2')}></div>
                <div className={getStepClassName('2')}>2</div>
                <div className={getClassName('2')}></div>
                <div className={getClassName('3')}></div>
                <div className={getStepClassName('3')}>3</div>
                <div className={getClassName('3')}></div>
                <div className={getClassName('4')}></div>
                <div className={getStepClassName('4')}>4</div>
            </div>
        </div>
    )
}
