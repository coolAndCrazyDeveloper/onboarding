import React from 'react'

export default function Block({ imgSrc, title, desc, currentType, setCurrentType }) {
    return (
        <div className='block-wrapper' style={{ border: (currentType === title ? '1px solid #6857e5' : '') }} onClick={() => setCurrentType(title)}>
            <div><img src={imgSrc} alt="" /></div>
            <div>
                <p className='block-title'>{title}</p>
                <p className='block-desc'>{desc}</p>
            </div>
        </div>
    )
}
