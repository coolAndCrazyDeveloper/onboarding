import logo from './logo.svg';
import Layout from './features/layout/Layout';
import './style/mainStyle.css'

function App() {
  return (
    <Layout />
  );
}

export default App;
